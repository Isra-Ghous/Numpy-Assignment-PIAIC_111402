# Read Instructions carefully before attempting this assignment

1) don't rename any function name
2) don't rename any variable name
3) don't remove any #comment 
4) don't remove """ under triple quate values """
5) you have to write code where you found "write your code here"
6) after download rename this file with this format "PIAICCompletRollNumber_AssignmentNo.py"
  Example piaic17896_Assignment1.py
7) After complete this assignment please push on your own GitHub repository.
8) you can submit this assignment through the google form
9) copy this file absolute URL then paste in the google form
 The example above: https://github.com/EnggQasim/Batch04_to_35/blob/main/Sunday/1_30%20to%203_30/Assignments/assignment1.txt

* Because all assignment we will be checked through software if you missed any above points 
* then we can't assign your scores in our database.
